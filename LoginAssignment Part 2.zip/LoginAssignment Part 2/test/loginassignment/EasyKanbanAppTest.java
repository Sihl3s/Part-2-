/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package loginassignment;

/**
 *
 * @author sihle
 */
import static org.junit.Assert.*;
import org.junit.Test;
import java.util.ArrayList;

public class EasyKanbanAppTest {
 @Test
    public void testTaskDescriptionLength() {
        Task task1 = new Task();
        task1.setTaskDescription("Create Login to authenticate users");
        assertTrue(task1.checkTaskDescription()); // Should return true

        Task task2 = new Task();
        task2.setTaskDescription("Create Add Task feature to add task users and ensure the description is longer than 50 characters");
        assertFalse(task2.checkTaskDescription()); // Should return false
    }

    @Test
    public void testTaskIDGeneration() {
        Task task1 = new Task();
        task1.setTaskName("Login Feature");
        task1.setDeveloperDetails("Robyn Harrison");
        assertEquals("AD:0:RHN", task1.createTaskID());

        Task task2 = new Task();
        task2.setTaskName("Add Task Feature");
        task2.setDeveloperDetails("Mike Smith");
        assertEquals("AD:1:MSH", task2.createTaskID());
    }

    @Test
    public void testTotalHoursAccumulation() {
        // Additional test data for 5 tasks with durations 10, 12, 55, 11, 1
        ArrayList<Task> tasks = new ArrayList<>();
        tasks.add(new Task("Task 1", "Description", "Developer", 10, "Status"));
        tasks.add(new Task("Task 2", "Description", "Developer", 12, "Status"));
        tasks.add(new Task("Task 3", "Description", "Developer", 55, "Status"));
        tasks.add(new Task("Task 4", "Description", "Developer", 11, "Status"));
        tasks.add(new Task("Task 5", "Description", "Developer", 1, "Status"));

        double totalHours = 0;
        for (Task task : tasks) {
            totalHours += task.getTaskDuration();
        }

        assertEquals(89, totalHours, 0); // Should return 89
    }
}
