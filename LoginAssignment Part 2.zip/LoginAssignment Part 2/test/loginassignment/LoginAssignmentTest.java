/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package loginassignment;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author sihle
 */
public class LoginAssignmentTest {

    public LoginAssignmentTest() {
    }

    @Test
    public void checkUsername() {
        boolean expected = true;
        String username = "kyl_1";
        boolean actual = LoginRegister.checkUsername(username);
        assertEquals(expected, actual);

    }

    @Test
    public void checkPasswordComplexity() {
        boolean expected = true;
        String password = "Ch&&sec@ke99!";
        boolean actual = LoginRegister.checkPasswordComplexity(password);
        assertEquals(expected, actual);
    }
    @Test
    public void loginUser() {
        boolean expected = true;
        String username = "kyl_1";
        String password = "Ch&&sec@ke99!";
        LoginAssignment log = new LoginAssignment();
        LoginRegister register =  new LoginRegister();
        boolean actual = log.loginUser(register);
        
        assertEquals(expected, actual);
    }
}
