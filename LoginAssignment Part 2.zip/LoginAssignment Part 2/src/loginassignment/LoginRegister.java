/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package loginassignment;

import javax.swing.JOptionPane;

/**
 *
 * @author sihle
 */
public class LoginRegister {
   private String username, password, firstName, lastName;

    // Default constructor
    public LoginRegister() {
        this.username = "";
        this.password = "";
        this.firstName = "";
        this.lastName = "";
    }

    public LoginRegister(String username, String password, String firstName, String lastName) {
        this.username = username;
        this.password = password;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public static boolean checkUsername(String username) {
        if (username != null && username.length() <= 5 && username.contains("_")) {
            JOptionPane.showMessageDialog(null, "Username successfully captured");
            return true;
        } else {
            JOptionPane.showMessageDialog(null, "Username is not correctly formatted, "
                    + "please ensure your username contains an underscore and is no longer than 5 characters in length");
            return false;
        }
    }

    public static boolean checkPasswordComplexity(String password) {
        boolean hasCapital = false;
        boolean hasSpecialChar = false;
        boolean hasNumber = false;

        if (password.length() < 8) {
            return false;
        }

        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) {
                hasCapital = true;
            } else if (Character.isDigit(c)) {
                hasNumber = true;
            } else if (!Character.isLetterOrDigit(c)) {
                hasSpecialChar = true;
            }
        }

        return hasCapital && hasSpecialChar && hasNumber;
    }

    public boolean checkLogin(String username, String password) {
        return getUsername().equals(username) && getPassword().equals(password);
    }
    public String returnLoginStatus() {
        if (!getUsername().isEmpty() && !getPassword().isEmpty()) {
            return "Logged in";
        } else {
            return "Not logged in";
        }
    } 
}
