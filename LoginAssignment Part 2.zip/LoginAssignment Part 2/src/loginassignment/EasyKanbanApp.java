/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package loginassignment;

import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author sihle
 */
public class EasyKanbanApp {
    public EasyKanbanApp() {
        JOptionPane.showMessageDialog(null, "Welcome to EasyKanban");

        ArrayList<Task> tasks = new ArrayList<>();
        int numTasks = Integer.parseInt(JOptionPane.showInputDialog("Enter the number of tasks:"));

        for (int i = 0; i < numTasks; i++) {
            Task task = new Task();
            task.setTaskName(JOptionPane.showInputDialog("Enter Task Name:"));
            task.setTaskDescription(JOptionPane.showInputDialog("Enter Task Description:"));
            task.setDeveloperDetails(JOptionPane.showInputDialog("Enter Developer Details:"));
            task.setTaskDuration(Double.parseDouble(JOptionPane.showInputDialog("Enter Task Duration (hours):")));
            task.setTaskStatus(JOptionPane.showInputDialog("Select Task Status: To Do, Done, or Doing"));

            if (task.checkTaskDescription()) {
                tasks.add(task);
                JOptionPane.showMessageDialog(null, "Task successfully captured:\n" + task.printTaskDetails());
            } else {
                JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters.");
                i--; // Decrement i to re-enter the task details
            }
        }

        double totalHours = 0;
        StringBuilder allTasksDetails = new StringBuilder("All Tasks Details:\n");
        for (Task task : tasks) {
            allTasksDetails.append(task.printTaskDetails()).append("\n");
            totalHours += task.getTaskDuration();
        }
        JOptionPane.showMessageDialog(null, allTasksDetails.toString() + "\nTotal Hours: " + totalHours);
    }
}
