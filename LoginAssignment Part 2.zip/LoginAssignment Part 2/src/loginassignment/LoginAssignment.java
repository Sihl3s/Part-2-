/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package loginassignment;

import javax.swing.JOptionPane;

/**
 *
 * @author sihle
 */
public class LoginAssignment {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
LoginRegister loginregister = new LoginRegister();

        boolean running = true;
        while (running) {
            String[] options = {"Register", "Login", "Cancel"};
            int choice = JOptionPane.showOptionDialog(null, "Choose an option:", "Login/Register System",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, options, options[0]);

            if (choice == 0) { // Register
                registerUser(loginregister);
            } else if (choice == 1) { // Login
                boolean loggedIn = loginUser(loginregister);
                if (loggedIn) {
                    JOptionPane.showMessageDialog(null, "Welcome " + loginregister.getFirstName() + " " + loginregister.getLastName()
                            + ", it is great to see you.");
                    EasyKanbanApp kanbanApp = new EasyKanbanApp();
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid username or password.");
                }
                String loginStatus = loginregister.returnLoginStatus();
                JOptionPane.showMessageDialog(null,"Login Status: " + loginStatus);
            } else if (choice == 2) { // Cancel
                running = false;
            }
        }
    }

    public static void registerUser(LoginRegister register) {
        String firstname = JOptionPane.showInputDialog(null, "Enter first name: ");
        register.setFirstName(firstname);
        String lastName = JOptionPane.showInputDialog(null, "Enter last name: ");
        register.setLastName(lastName);

        boolean isValidUsername = false;
        while (!isValidUsername) {
            //input
            String username = JOptionPane.showInputDialog(null, "Enter username:");
            //testing if valid
            isValidUsername = register.checkUsername(username);
            //setting
        register.setUsername(username);
        }
        
        
        boolean isValidPassword = false;
        while (!isValidPassword) {
            String password = JOptionPane.showInputDialog(null, "Enter password:");
            isValidPassword = register.checkPasswordComplexity(password);
            if (!isValidPassword) {
                JOptionPane.showMessageDialog(null, "Password is not correctly formatted,"
                        + " please ensure that the password contains at least 8 characters, "
                        + "a capital letter, a number, and a special character");
            } else {
                register.setPassword(password); // Set the password after validation
            }
        }
        JOptionPane.showMessageDialog(null, "User registered successfully!");
    }

    public static boolean loginUser(LoginRegister register) {
        String username = JOptionPane.showInputDialog(null, "Enter username:");
        String password = JOptionPane.showInputDialog(null, "Enter password:");

        return register.checkLogin(username, password);
    }
}
