/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package loginassignment;

/**
 *
 * @author sihle
 */
public class Task {

    private String taskName;
    private int taskNumber;
    private String taskDescription;
    private String developerDetails;
    private double taskDuration;
    private String taskID;
    private String taskStatus;

    private static int taskCount = 0;

    public Task() {
        taskNumber = taskCount++;
    }

    public Task(String taskName, String taskDescription, String developerDetails, double taskDuration, String taskStatus) {
        this.taskName = taskName;
        this.taskDescription = taskDescription;
        this.developerDetails = developerDetails;
        this.taskDuration = taskDuration;
        this.taskStatus = taskStatus;
        this.taskNumber = taskCount++;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public void setTaskDescription(String taskDescription) {
        this.taskDescription = taskDescription;
    }

    public void setDeveloperDetails(String developerDetails) {
        this.developerDetails = developerDetails;
    }

    public void setTaskDuration(double taskDuration) {
        this.taskDuration = taskDuration;
    }

    public double getTaskDuration() {
        return taskDuration;
    }

    public void setTaskStatus(String taskStatus) {
        this.taskStatus = taskStatus;
    }

    public boolean checkTaskDescription() {
        return taskDescription.length() <= 50;
    }

    public String createTaskID() {
        String firstTwoLetters = taskName.substring(0, Math.min(taskName.length(), 2));
        String lastThreeLetters = developerDetails.substring(Math.max(developerDetails.length() - 3, 0));
        taskID = firstTwoLetters.toUpperCase() + ":" + taskNumber + ":" + lastThreeLetters.toUpperCase();
        return taskID;
    }

    public String printTaskDetails() {
        createTaskID(); // Ensure Task ID is generated before printing details
        return "Task Status: " + taskStatus
                + "\nDeveloper Details: " + developerDetails
                + "\nTask Number: " + taskNumber
                + "\nTask Name: " + taskName
                + "\nTask Description: " + taskDescription
                + "\nTask ID: " + taskID
                + "\nDuration: " + taskDuration + " hours";
    }
}
